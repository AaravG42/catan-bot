"""Bounded same-turn search using the handcrafted tactical evaluator.

No network, fitting or RL. Search only deterministic public actions; chance
actions are evaluated once and never followed by optimistic best-outcome search.
"""
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
for folder in (ROOT, ROOT / 'codex' / 'heuristics', ROOT / 'agents' / 'common'):
    if str(folder) not in sys.path:
        sys.path.append(str(folder))

from codex.evaluator_swap.frozen.exploit import ExploitAgent, blocked_need
from codex.evaluator_swap.frozen.outcomes import outcomes as exact_outcomes
from codex.evaluator_swap.frozen.core import outcomes as baseline_outcomes
from codex.evaluator_swap.frozen.feats import DEVS
from catanatron.models.enums import ActionType as AT
from codex.evaluator_swap.frozen import opening

BUILDS = {AT.BUILD_CITY, AT.BUILD_SETTLEMENT, AT.BUILD_ROAD}
CONTINUE = BUILDS | {AT.MARITIME_TRADE, AT.PLAY_YEAR_OF_PLENTY,
                     AT.PLAY_MONOPOLY, AT.PLAY_ROAD_BUILDING}
PRESETS = {
    'army_fast': ('army', 2, 3, .004, 50, False),
    'army_deep': ('army', 4, 4, .010, 120, False),
    'counter_fast': ('counter', 2, 3, .004, 50, False),
    'counter_deep': ('counter', 4, 4, .010, 120, False),
    'army_exact': ('army', 3, 3, .006, 80, True),
}


def state_key(game):
    """Within-decision transposition key; includes hands, board and forced phase.

    Map and unseen deck are constant within our deterministic continuation tree.
    Ordered road history matters to engine tie breaking, so preserve its order.
    """
    s = game.state
    return (tuple(sorted(s.player_state.items())), tuple(s.board.buildings.items()),
            tuple(s.board.roads.items()), s.board.robber_coordinate,
            s.current_player_index, s.current_turn_index, s.current_prompt,
            s.is_road_building, s.free_roads_available, s.is_moving_knight,
            tuple(s.resource_freqdeck))


class GuardedSearchAgent(ExploitAgent):
    def __init__(self, preset='army_fast'):
        profile, self.depth, self.beam, self.cap, self.nodes, self.exact = PRESETS[preset]
        super().__init__(profile)
        self.last_stats = {}

    def emergency(self, obs, actions, deadline):
        """Legal, cheap fallback; prefer actual point builds, otherwise end turn."""
        priority = {AT.BUILD_CITY: 0, AT.BUILD_SETTLEMENT: 1, AT.END_TURN: 2,
                    AT.ROLL: 3, AT.PLAY_KNIGHT_CARD: 4}
        index = min(range(len(actions)), key=lambda i: priority.get(actions[i].action_type, 5))
        # At a genuinely tiny bank avoid even world reconstruction.
        if deadline-time.process_time() < .003:
            return index
        world = obs.sample_world(self.base.rng)
        key = 'P%d_ACTUAL_VICTORY_POINTS' % world.state.color_to_index[obs.me]
        for i, action in enumerate(actions):
            if time.process_time() >= deadline:
                break
            if action.action_type not in BUILDS | {AT.PLAY_KNIGHT_CARD}:
                continue
            child = world.copy()
            child.execute(action, validate_action=False)
            if child.state.player_state[key] >= world.vps_to_win:
                return i
        return index

    def decide(self, obs, actions):
        started = time.process_time()
        left = obs.cpu_left if obs.cpu_left is not None else 1.
        # Entire decision deadline, retaining a 15 ms bank for atomic engine and
        # evaluator operations that cannot be preempted safely in Python.
        hard_deadline = started + min(.060, max(0., left-.015))
        fallback = lambda: self.emergency(obs, actions, min(hard_deadline, started+.003))
        if len(actions) == 1:
            return 0
        if left < .030:
            return fallback()
        if obs._game.state.is_initial_build_phase:
            budget = min(.05, max(0., min(left*.2, hard_deadline-time.process_time())))
            return opening.choose(obs, actions, budget, 'balanced')
        world = obs.sample_world(self.base.rng)
        me = obs.me
        key = 'P%d_' % world.state.color_to_index[me]
        initial_block = blocked_need(world, me)
        ps = world.state.player_state
        outcomes = exact_outcomes if self.exact else baseline_outcomes
        scores, successors, statics = [], [], []
        def completed_best():
            return max(range(len(scores)), key=lambda i: scores[i]) if scores else fallback()

        class RootDeadline(Exception):
            pass

        def forced_knight(game):
            values = []
            for action in game.playable_actions:
                if action.action_type != AT.MOVE_ROBBER:
                    continue
                if time.process_time() >= hard_deadline:
                    raise RootDeadline
                value = 0.
                for child, probability in exact_outcomes(game, action, me):
                    if time.process_time() >= hard_deadline:
                        raise RootDeadline
                    value += probability*self.robber_value(child, me, initial_block)
                values.append(value)
            return max(values) if values else self.value(game, me)
        for action in actions:
            if time.process_time() >= hard_deadline:
                return completed_best()
            typ = action.action_type
            outs = outcomes(world, action, me)
            score = 0.
            static = None
            rv = getattr(self, 'root_v', None)
            for game, probability in outs:
                if time.process_time() >= hard_deadline:
                    return completed_best()
                if game.state.player_state[key+'ACTUAL_VICTORY_POINTS'] >= world.vps_to_win:
                    if typ in BUILDS or typ == AT.PLAY_KNIGHT_CARD:
                        return actions.index(action)
                    value = 1e18
                elif typ == AT.MOVE_ROBBER:
                    value = self.robber_value(game, me, initial_block)
                elif typ == AT.PLAY_KNIGHT_CARD:
                    try:
                        value = forced_knight(game)
                    except RootDeadline:
                        return completed_best()
                else:
                    value = self.value(game, me)
                score += probability*value
                if rv is not None and value < 1e17:
                    score += probability*rv(game, me)
                static = value
            if typ == AT.PLAY_MONOPOLY and obs.opp_resources[action.value] >= 3:
                score += self.profile['monopoly']*(obs.opp_resources[action.value]-2)
            if typ == AT.BUY_DEVELOPMENT_CARD and self.profile['army']:
                other = 'P%d_' % (1-world.state.color_to_index[me])
                target = max(3, ps[other+'PLAYED_KNIGHT']+1)
                progress = ps[key+'PLAYED_KNIGHT']+ps[key+'KNIGHT_IN_HAND']
                if not ps[key+'HAS_ARMY'] and 0 < target-progress <= 2:
                    unseen = list(world.state.development_listdeck)
                    for d in DEVS:
                        unseen += [d]*ps[other+d+'_IN_HAND']
                    if unseen:
                        score += self.profile['army']*(unseen.count('KNIGHT')/len(unseen))*(3-target+progress)
            scores.append(score)
            successors.append(outs[0][0] if typ in CONTINUE and len(outs) == 1 else None)
            statics.append(static)

        # Reserve the complete one-ply fallback. Search gets a modest fraction of
        # remaining allowance, with both a CPU and node ceiling.
        now = time.process_time()
        remaining = max(0., left-(now-started))
        budget = min(self.cap, max(0., (remaining-.10)*.04), max(0., hard_deadline-now))
        deadline = now+budget
        expanded = 0
        cache = {}
        root_order = sorted(range(len(actions)), key=lambda i: scores[i], reverse=True)
        selected = [i for i in root_order if successors[i] is not None][:self.beam]
        # Keep one trade and road outside the usual beam: their immediate value
        # can dip before the point-producing continuation becomes visible.
        for typ in (AT.MARITIME_TRADE, AT.BUILD_ROAD, AT.PLAY_YEAR_OF_PLENTY):
            extra = next((i for i in root_order if actions[i].action_type == typ), None)
            if extra is not None and extra not in selected:
                selected.append(extra)
        bonuses = [scores[i]-statics[i] if successors[i] is not None else 0.
                   for i in range(len(actions))]

        def deepen(game, depth, stand):
            nonlocal expanded
            if (depth <= 0 or expanded >= self.nodes or time.process_time() >= deadline
                    or game.state.current_color() != me):
                return stand
            state = (state_key(game), depth)
            if state in cache:
                return cache[state]
            rows = []
            # Resolve direct builds first (Catan analogue of tactical move
            # ordering). Quiescence at the horizon includes only builds.
            choices = [a for a in game.playable_actions
                       if a.action_type in (BUILDS if depth == 1 else CONTINUE)]
            choices.sort(key=lambda a: 0 if a.action_type in BUILDS else 1)
            best = stand
            complete = True
            for action in choices:
                if expanded >= self.nodes or time.process_time() >= deadline:
                    complete = False
                    break
                child = game.copy()
                child.execute(action, validate_action=False)
                expanded += 1
                if child.state.player_state[key+'ACTUAL_VICTORY_POINTS'] >= world.vps_to_win:
                    return 1e18
                value = self.value(child, me)
                continuation_v = getattr(self, 'continuation_v', None)
                if continuation_v is not None:
                    value += continuation_v(child, me)
                best = max(best, value)
                rows.append((value, child))
            if depth > 1:
                rows.sort(key=lambda row: row[0], reverse=True)
                for value, child in rows[:self.beam]:
                    if expanded >= self.nodes or time.process_time() >= deadline:
                        complete = False
                        break
                    best = max(best, deepen(child, depth-1, value))
            # Memoize only before exhausting either budget. Values are selective
            # search lower bounds, never full-width minimax/exact evaluations.
            if complete and expanded < self.nodes and time.process_time() < deadline:
                cache[state] = best
            return best

        # Iterative depth makes all selected root moves compete at short depth
        # before spending the remaining allowance on a longer continuation.
        for depth in range(1, self.depth):
            selected.sort(key=lambda i: scores[i], reverse=True)
            for i in selected:
                if expanded >= self.nodes or time.process_time() >= deadline:
                    break
                leaf = deepen(successors[i], depth, statics[i])
                if leaf >= 1e18:
                    return i
                # Keep root-only tactical bonuses, without accumulating them
                # repeatedly along a path or mixing raw and augmented scales.
                scores[i] = max(scores[i], leaf + bonuses[i])
        self.last_stats = dict(expanded=expanded, transpositions=len(cache), budget=budget)
        return max(range(len(actions)), key=lambda i: scores[i])
