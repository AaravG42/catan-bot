"""Fixed-eight residual ablations of the exact submitted heuristic/search."""
from pathlib import Path
import numpy as np
from codex.residual_sweep.guarded import GuardedSearchAgent
from codex.residual_sweep.core import Value, EnsValue
from codex.evaluator_swap.baseline import PARAMS
from codex.evaluator_swap.frozen.strategy import heuristic
from codex.evaluator_swap.frozen.feats import feats

NETS=Path(__file__).resolve().parent/'nets'
K=8.

class ResidualAgent(GuardedSearchAgent):
    def __init__(self,network='ensemble',placement='both'):
        super().__init__('army_exact')
        if network not in ('v5','v3','ensemble') or placement not in ('root_only','continuation_only','both'):
            raise ValueError((network,placement))
        self.network,self.placement=network,placement
        self.profile=dict(self.profile)
        self.profile.update(denial=PARAMS['denial'],monopoly=PARAMS['monopoly'],army=PARAMS['tactical_army'])
        weights={k:PARAMS[k] for k in ('prod','expand','army','hand','econ')}
        self.net=(Value(str(NETS/('value_v5.npz' if network=='v5' else 'value.npz'))) if network!='ensemble' else
                  EnsValue(str(NETS/'value.npz'),str(NETS/'value_v5.npz')))
        self.base.value=lambda game,me:heuristic(game,me,weights)
        self.root_v=self.residual if placement=='root_only' else None
        self.continuation_v=self.residual if placement=='continuation_only' else None
        if placement=='both':
            self.base.value=lambda game,me:heuristic(game,me,weights)+self.residual(game,me)

    def residual(self,game,me):
        p=float(self.net([feats(game,me)])[0])
        p=min(max(p,1e-6),1-1e-6)
        return K*np.log(p/(1-p))
