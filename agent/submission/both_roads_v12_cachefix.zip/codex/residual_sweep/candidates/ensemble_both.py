from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path: sys.path.append(str(ROOT))
from codex.residual_sweep.runtime import ResidualAgent
class Agent(ResidualAgent):
    def __init__(self):
        super().__init__('ensemble', 'both')
