from codex.v12_open.runtime import OpeningAgent
class Agent(OpeningAgent):
    def __init__(self):super().__init__('ensemble')
