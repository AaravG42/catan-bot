"""Transplant v12's setup rollout only; preserve each base main-turn policy."""
from pathlib import Path
from catanatron.models.enums import ActionType
from codex.v12_open.frozen.agent import Agent as V12, _npv
from codex.v12_open.frozen.core import Value
from codex.novel_quick.runtime import NovelAgent
from codex.residual_sweep.runtime import ResidualAgent
from codex.evaluator_swap.baseline import Agent as Baseline

class OpeningAgent:
    def __init__(self,base):
        self.base=(NovelAgent('v11_root_only') if base=='v11' else
                   ResidualAgent('ensemble','root_only') if base=='ensemble' else Baseline())
        self.open=V12.__new__(V12)
        self.open.V=Value(str(Path(__file__).parent/'frozen/value.npz'))
    def decide(self,obs,actions):
        g=obs._game
        if len(actions)>1 and g.state.is_initial_build_phase and actions[0].action_type==ActionType.BUILD_SETTLEMENT:
            # Scope the source's map cache to this decision (no policy change).
            _npv.cache.clear()
            try:return self.open.opening(g,actions,obs.me)
            finally:_npv.cache.clear()
        return self.base.decide(obs,actions)
