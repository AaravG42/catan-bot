from codex.novel_quick.runtime import NovelAgent
class Agent(NovelAgent):
    def __init__(self):
        super().__init__('agreement')
