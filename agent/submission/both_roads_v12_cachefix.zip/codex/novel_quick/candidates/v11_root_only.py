from codex.novel_quick.runtime import NovelAgent
class Agent(NovelAgent):
    def __init__(self):
        super().__init__('v11_root_only')
