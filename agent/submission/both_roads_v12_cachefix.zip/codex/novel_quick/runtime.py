"""Small hypothesis screen: richer features, phase gating, model disagreement."""
from pathlib import Path
import numpy as np
from codex.residual_sweep.runtime import ResidualAgent
from codex.residual_sweep.core import Value
from codex.evaluator_swap.frozen.feats import feats
from codex.novel_quick.frozen.efeats2 import efeats2
from codex.novel_quick.frozen.obs_np import encode_game

def logit(p):
    p=float(np.clip(p,1e-6,1-1e-6))
    return np.log(p/(1-p))

class NovelAgent(ResidualAgent):
    def __init__(self,mode):
        self.mode=mode
        super().__init__('ensemble', mode[4:] if mode.startswith('v11_') else 'both')
        if mode.startswith('v11_'):
            self.net=Value(str(Path(__file__).parent/'frozen/value.npz'))

    def residual(self,game,me):
        if self.mode.startswith('v11_'):
            return 8*logit(self.net(efeats2(encode_game(game,me)[None]))[0])
        x=[feats(game,me)]
        z=[logit(n(x)[0]) for n in self.net.nets]
        value=4*sum(z)
        if self.mode=='agreement':
            return value/(1+abs(z[0]-z[1]))
        if self.mode=='late':
            ps=game.state.player_state
            mine=game.state.color_to_index[me]
            vp=max(ps[f'P{mine}_ACTUAL_VICTORY_POINTS'],ps[f'P{1-mine}_VICTORY_POINTS'])
            return value*np.clip((vp-4)/4,0,1)
        if self.mode=='bounded':
            return 8*np.tanh(value/8)
        raise ValueError(self.mode)
