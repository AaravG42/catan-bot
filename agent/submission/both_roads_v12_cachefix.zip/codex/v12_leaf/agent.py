from codex.v12_open.runtime import OpeningAgent
from codex.residual_sweep.runtime import ResidualAgent
class Agent(OpeningAgent):
    def __init__(self):
        super().__init__('baseline')
        self.base=ResidualAgent('ensemble','both')
