import os
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[name]='1'
from codex.setup_roads.runtime import Roads
class Agent(Roads):
    def __init__(self):super().__init__('both')
