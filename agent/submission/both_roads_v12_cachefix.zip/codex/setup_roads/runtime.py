from catanatron.models.enums import ActionType,SETTLEMENT,CITY
from codex.v12_leaf.agent import Agent as Base
from codex.v12_open.frozen.agent import _npv

class Roads(Base):
    def __init__(self,mode):
        super().__init__();self.mode=mode
    def decide(self,obs,actions):
        g=obs._game
        if len(actions)>1 and g.state.is_initial_build_phase and actions[0].action_type==ActionType.BUILD_ROAD:
            b=g.state.buildings_by_color[obs.me]
            first=len(b[SETTLEMENT])+len(b[CITY])==1
            if self.mode=='both' or first:
                _npv.cache.clear()
                try:return self.open.opening(g,actions,obs.me)
                finally:_npv.cache.clear()
        return super().decide(obs,actions)
