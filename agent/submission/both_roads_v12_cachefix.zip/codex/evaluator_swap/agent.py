"""Evaluator-only swap: submitted search with frozen v5 probability in score units."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:sys.path.append(str(ROOT))
from codex.evaluator_swap.baseline import Agent as SubmittedAgent
from codex.evaluator_swap.frozen.core import Value
from codex.evaluator_swap.frozen.feats import feats

V5_PATH=ROOT/'codex/version_eval/snapshots/v5/value.npz'
SCORE_SCALE=100.

class Agent(SubmittedAgent):
    def __init__(self):
        super().__init__()
        # V5's Value/feats are byte-identical to these submitted helpers apart
        # from namespaced imports; tests verify that contract and the NPZ shape.
        self.v5=Value(str(V5_PATH))
        self.base.value=self.v5_score

    def v5_score(self,game,me):
        key='P%d_ACTUAL_VICTORY_POINTS'%game.state.color_to_index[me]
        if game.state.player_state[key]>=game.vps_to_win:
            return 1e9  # preserve the original base heuristic's terminal contract
        probability=float(self.v5([feats(game,me)])[0])
        return SCORE_SCALE*(probability-.5)
