"""Fast pair-aware opening heuristics; resource order WOOD BRICK SHEEP WHEAT ORE.

EABR follows origin/heuristic rambling/04-placement-formalized.md. Scores are
in pip-equivalent units. Uses public board only; never reads hidden game state.
"""
from collections import deque
from functools import lru_cache
import numpy as np

RESOURCES = ('WOOD', 'BRICK', 'SHEEP', 'WHEAT', 'ORE')


def _data(board):
    nodes = sorted(board.map.land_nodes)
    n = max(nodes) + 1
    production = np.zeros((n, 5))
    tile_income = np.zeros((n, len(board.map.land_tiles)))
    tile_resource = []
    for j, tile in enumerate(board.map.land_tiles.values()):
        r = RESOURCES.index(tile.resource) if tile.resource in RESOURCES else 0
        tile_resource.append(r)
        if tile.resource is None:
            continue
        p = 6 - abs(7 - tile.number)
        for node in tile.nodes.values():
            production[node, r] += p
            tile_income[node, j] = p
    rates = np.full((n, 5), 4.0)
    for r, ns in board.map.port_nodes.items():
        for node in ns:
            if r is None:
                rates[node] = np.minimum(rates[node], 3)
            elif r in RESOURCES:
                rates[node, RESOURCES.index(r)] = 2
    adj, distances = _topology(tuple(nodes), tuple(sorted(board.buildable_subgraph.edges())))
    return nodes, production, tile_income, np.array(tile_resource), rates, adj, distances


@lru_cache(maxsize=4)
def _topology(nodes, edges):
    n = max(nodes) + 1
    adj = {a: [] for a in nodes}
    for a, b in edges:
        adj[a].append(b)
        adj[b].append(a)
    distances = np.full((n, n), 100, dtype=np.int16)
    for a in nodes:
        distances[a, a] = 0
        q = deque([a])
        while q:
            u = q.popleft()
            for v in adj[u]:
                if distances[a, v] == 100:
                    distances[a, v] = distances[a, u] + 1
                    q.append(v)
    return adj, distances


def _eabr(p, rates, demand):
    """Largest affordable plan rate, accounting for surplus bank/port trades."""
    demand = np.asarray(demand, dtype=float)
    demand /= demand.sum()
    low = np.zeros(p.shape[:-1])
    high = p.sum(axis=-1)
    for _ in range(15):
        mid = (low + high) * .5
        gap = p - mid[..., None] * demand
        feasible = (np.maximum(gap, 0) / rates).sum(axis=-1) >= np.maximum(-gap, 0).sum(axis=-1)
        low = np.where(feasible, mid, low)
        high = np.where(feasible, high, mid)
    return low


def choose(obs, playable_actions, cpu_budget_s=.05, style='balanced'):
    if len(playable_actions) == 1:
        return 0
    board = obs.board
    nodes, p, ti, tr, rates, adj, dist = _data(board)
    own = [n for n, (c, _) in board.buildings.items() if c == obs.me]
    legal = np.array(sorted(board.board_buildable_ids), dtype=int)
    demand = {
        'city': (2, 2, 3, 6, 7),
        'expand': (5, 5, 3, 4, 3),
        'port': (3, 3, 3, 5, 6),
        'balanced': (3, 3, 3, 5, 6),
        'pips': (1, 1, 1, 1, 1),
    }[style]

    def score(a, b):
        prod = p[a] + p[b]
        income = ti[a] + ti[b]
        # F suppresses productive tiles: modest expected discount, not a hard veto.
        if style != 'pips':
            worst = income.argmax(axis=-1)
            suppression = income.max(axis=-1) * (.18 if style == 'expand' else .30)
            prod = prod.copy()
            np.put_along_axis(prod, tr[worst][..., None],
                              np.take_along_axis(prod, tr[worst][..., None], axis=-1) - suppression[..., None], axis=-1)
        k = np.minimum(rates[a], rates[b])
        val = _eabr(prod, k, demand)
        if style == 'balanced':
            val = np.maximum(val, _eabr(prod, k, (4, 4, 3, 5, 5)))
        if style == 'pips':
            val = prod.sum(axis=-1) + 1.2 * np.minimum(prod, 2).sum(axis=-1)
        else:
            val += .13 * prod.sum(axis=-1)
        if style == 'port':
            val += .5 * ((4-k) * np.maximum(prod-4, 0)).sum(axis=-1)
        return val

    if playable_actions[0].action_type.name == 'BUILD_ROAD':
        # Follow each legal initial road toward a high-quality third settlement.
        current = p[own].sum(axis=0)
        current_rates = rates[own].min(axis=0)
        base = _eabr(current, current_rates, demand)
        future = _eabr(current[None, :] + p[legal],
                       np.minimum(current_rates[None, :], rates[legal]), demand)
        gains = future - base + .12 * p[legal].sum(axis=1)
        vals = []
        for action in playable_actions:
            u, v = action.value
            if v in own:
                u, v = v, u
            distance = dist[v, legal]
            valid = (distance > 0) & (dist[u, legal] >= distance)
            values = np.where(valid, gains / (distance + .65), -100.)
            vals.append(float(values.max()) if len(values) else -100.)
        return int(np.argmax(vals))

    candidates = np.array([a.value for a in playable_actions], dtype=int)
    if own:
        val = score(candidates, np.full(len(candidates), own[0]))
        # Starting cards matter: expansion can begin immediately with wood + brick.
        start = (p[candidates] > 0).astype(float)
        val += .22 * start[:, 0] + .22 * start[:, 1] + .10 * start[:, 3]
    elif cpu_budget_s is not None and cpu_budget_s < .008:
        # Graceful low-clock fallback: coverage-weighted pips without pair search.
        val = p[candidates].sum(axis=1) + np.minimum(p[candidates], 2).sum(axis=1)
    else:
        aa = candidates[:, None]
        bb = legal[None, :]
        pair = score(aa, bb)
        pair = np.where(dist[aa, bb] >= 2, pair, -1000)
        # Average several good continuations to avoid a brittle perfect-pair plan.
        top = np.sort(pair, axis=1)[:, -4:]
        val = .55 * top[:, -1] + .45 * top.mean(axis=1)
        val += .10 * p[candidates].sum(axis=1)
    # Nearby third settlements: available production reachable in two roads.
    weight = .22 if style == 'expand' else .055
    available_quality = p[legal].sum(axis=1)
    for i, node in enumerate(candidates):
        options = available_quality[dist[node, legal] == 2]
        if len(options):
            val[i] += weight * np.sort(options)[-2:].mean()
    return int(np.argmax(val))
