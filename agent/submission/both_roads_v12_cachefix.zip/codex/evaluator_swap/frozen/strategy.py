"""Cheap, interpretable pool agents. No fitted parameters or evaluation-seed training.

The four f_* presets correct the existing FVariant factory bug: base_fn accepts custom
weights, get_value_fn('base_fn', weights) silently discards them. The remaining presets
use bounded economic terms instead of F's lexicographic production preference.
"""
import math
import os
import random
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
COMMON = os.path.join(ROOT, 'agents', 'common')
if COMMON not in sys.path:
    sys.path.append(COMMON)
from codex.evaluator_swap.frozen.feats import feats, feat_names
from codex.evaluator_swap.frozen.core import outcomes
from catanatron.models.enums import ActionType
from catanatron.players.value import DEFAULT_WEIGHTS, base_fn

F_VALUE = base_fn(DEFAULT_WEIGHTS)
NAMES = {name: i for i, name in enumerate(feat_names())}
RES = ('WOOD', 'BRICK', 'SHEEP', 'WHEAT', 'ORE')
F_PRESETS = {
    'f_city': dict(reachable_production_0=2e4, reachable_production_1=2e3,
                   buildable_nodes=400, hand_synergy=500, hand_devs=20),
    'f_expand': dict(reachable_production_0=3e5, reachable_production_1=3e4,
                     buildable_nodes=3e3, hand_synergy=300),
    'f_army': dict(hand_devs=150, army_size=170, hand_synergy=80,
                   reachable_production_1=800, buildable_nodes=100),
    'f_tempo': dict(public_vps=100, production=35, enemy_production=-30,
                    reachable_production_0=3, reachable_production_1=1.5,
                    buildable_nodes=.5, hand_synergy=8, hand_resources=.15,
                    hand_devs=2, army_size=2.2, longest_road=.5,
                    num_tiles=.1, discard_penalty=-1),
}
PRESETS = {
    'balanced': dict(prod=22., expand=1., army=1.6, hand=1., econ=0.),
    'expand': dict(prod=25., expand=2., army=.8, hand=1.2, econ=0.),
    'army': dict(prod=18., expand=.65, army=3., hand=.9, econ=0.),
    'economic': dict(prod=10., expand=1., army=1.5, hand=1., econ=22.),
}


def economic_rate(prod, rates, demand):
    """Largest affordable plan rate, including actual bank/port exchange rates."""
    lo, hi = 0., sum(prod) / sum(demand)
    for _ in range(9):
        mid = (lo + hi) * .5
        net = sum((p-d*mid) / k if p >= d*mid else p-d*mid
                  for p, d, k in zip(prod, demand, rates))
        if net >= 0:
            lo = mid
        else:
            hi = mid
    return lo * sum(demand)


def heuristic(game, me, weights):
    x = feats(game, me)
    def f(name):
        return x[NAMES[name]]
    vp = f('me_actual_vp')
    if vp >= game.vps_to_win:
        return 1e9
    prod = [f('me_prod_' + r) for r in RES]
    hand = [f('me_hand_' + r) for r in RES]
    rates = [2 if f('me_port_'+r) else 3 if f('me_port_3to1') else 4 for r in RES]
    # Early income compounds; late in the game cashing in points takes priority.
    phase = max(.3, 1. - max(0., vp-4.) * .12)
    production = sum(prod) + .08 * sum(min(1., p/.08) for p in prod)
    enemy = f('opp_prod_total') + .08*f('opp_prod_distinct')
    score = 12*vp - 10*f('opp_vp') + phase*weights['prod']*(production - .8*enemy)
    if weights['econ']:
        rate = max(economic_rate(prod, rates, (2,2,1,2,3)),
                   economic_rate(prod, rates, (1,1,2,4,4)))
        score += phase * weights['econ'] * rate
    # Immediate expansion is more valuable than merely extending roads. Cap the
    # count: empty low-yield branches should not dominate a real purchase.
    expansion = (7*f('me_build_now_best') + 3*f('me_build_one_best')
                 + .25*min(3, f('me_build_now_n')) + .08*min(3, f('me_build_one_n')))
    score += phase * weights['expand'] * expansion
    # Goal-aware hand value. Ports enter as sell rates, never free bonuses.
    goals = []
    if f('me_n_sett') > 0 and f('me_n_city') < 4:
        goals.append(((0,0,0,2,3), 5.5))
    if f('me_build_now_n') and f('me_n_sett') < 5:
        goals.append(((1,1,1,1,0), 5.5))
    elif f('me_build_one_n') and f('me_n_sett') < 5:
        goals.append(((2,2,1,1,0), 4.))
    if f('deck_left'):
        goals.append(((0,0,1,1,1), 1.5+weights['army']*.3))
    ready = 0.
    for cost, value in goals:
        deficit = sum(max(0, c-h) for c,h in zip(cost,hand))
        surplus = sum(max(0, h-c)//k for c,h,k in zip(cost,hand,rates))
        ready = max(ready, value*(.8*math.exp(-.65*deficit)
                                  + .2*math.exp(-.65*max(0, deficit-surplus))))
    score += weights['hand'] * (ready + .12*sum(hand))
    score -= .10*max(0, sum(hand)-7)
    knights = f('me_knights')
    opponent_knights = f('opp_knights')
    target = max(3., opponent_knights+1)
    # Played knights approach the army threshold. Avoid valuing endless knights
    # once the award is safely held; robber benefits already appear in production.
    if not f('me_has_army'):
        score += weights['army'] * min(knights, target-1)
        knight_card = weights['army'] * (1.0 if knights < target else .3)
    else:
        knight_card = .4 + .35*(knights <= opponent_knights+1)
    score += knight_card*f('me_dev_KNIGHT')
    score += 1.3*f('me_dev_ROAD_BUILDING') + 1.5*f('me_dev_YEAR_OF_PLENTY')
    score += 1.8*f('me_dev_MONOPOLY')
    # Actual VP already includes VP cards: never count those twice.
    if not f('me_has_road'):
        score += .25*min(4., f('me_road_len'))
    return score


class StrategyAgent:
    def __init__(self, preset='balanced'):
        self.preset = preset
        self.rng = random.Random(0)
        if preset in F_PRESETS:
            weights = dict(DEFAULT_WEIGHTS)
            weights.update(F_PRESETS[preset])
            self.value = base_fn(weights)
        else:
            weights = PRESETS[preset]
            self.value = lambda g, me: heuristic(g, me, weights)

    def decide(self, obs, playable_actions):
        if len(playable_actions) == 1:
            return 0
        world = obs.sample_world(self.rng)
        # Opening strength is controlled separately; do not confound policy tests.
        opening = world.state.is_initial_build_phase
        value = F_VALUE if opening else self.value
        best_i, best_v = 0, -float('inf')
        for i, action in enumerate(playable_actions):
            # Exact chance expectation prevents choosing a bank trade or dev card
            # solely because its sampled outcome happened to be favourable.
            if opening:
                g = world.copy()
                g.execute(action)
                score = value(g, obs.me)
            else:
                score = 0.
                for g, probability in outcomes(world, action, obs.me):
                    own_key = 'P%d_ACTUAL_VICTORY_POINTS' % g.state.color_to_index[obs.me]
                    v = 1e18 if g.state.player_state[own_key] >= g.vps_to_win else value(g, obs.me)
                    score += probability*v
            if score > best_v:
                best_i, best_v = i, score
        return best_i
