"""Namespaced replica of the submitted constructor; unchanged policy control."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:sys.path.append(str(ROOT))
from codex.evaluator_swap.frozen.guarded import GuardedSearchAgent
from codex.evaluator_swap.frozen.strategy import heuristic
PARAMS={'army':2.49792,'denial':.35,'econ':0.,'expand':.71404,'hand':.9,
        'monopoly':.3037,'prod':18.,'tactical_army':1.4}
class Agent(GuardedSearchAgent):
    def __init__(self):
        super().__init__('army_exact')
        self.profile=dict(self.profile)
        self.profile.update(denial=PARAMS['denial'],monopoly=PARAMS['monopoly'],army=PARAMS['tactical_army'])
        weights={k:PARAMS[k] for k in ('prod','expand','army','hand','econ')}
        self.base.value=lambda game,me:heuristic(game,me,weights)
